The icons in this directory have been made by "Microsoft and any contributors",
see the [development repository](https://github.com/microsoft/vscode-icons/).

They are distributed under Creative Commons Attribution 4.0 International Public
License, see the LICENSE file in this directory.
