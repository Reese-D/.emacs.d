"""Unit tests for elpy."""

try:
    import unittest2
    import sys
    sys.modules['unittest'] = unittest2
except:
    pass
